/**
 * タイムライン/シーケンス系のコマンドIDを推測して返すユーティリティ
 * 成功した最初のIDを返す。見つからない場合は 0。
 */
function fbjumper_guessTimelineCmdId() {
    try {
        var names = [
            "タイムライン (T)", "タイムライン(T)", "タイムライン　(T)", "タイムライン",
            "タイムライン（T）", "タイムライン　（T）", "タイムラインパネル", "タイムラインパネル (T)", "タイムラインパネル（T）",
            "Timeline (T)", "Timeline(T)", "Timeline", "Timeline Panel", "Timeline Panel (T)",
            "シーケンス", "シーケンス (T)", "シーケンス(T)", "シーケンスパネル", "シーケンスパネル (T)",
            "Sequence", "Sequence (T)", "Sequence(T)", "Sequence Panel", "Sequence Panel (T)"
        ];
        for (var i = 0; i < names.length; i += 1) {
            try {
                var cmd = app.findMenuCommandId(names[i]);
                if (cmd && cmd !== 0) {
                    return "OK:" + cmd;
                }
            } catch (e) {
                // continue
            }
        }
        return "ERR: not found";
    } catch (e) {
        return "ERR: " + e.toString();
    }
}
