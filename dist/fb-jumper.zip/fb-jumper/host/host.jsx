// ExtendScript では Array.prototype.indexOf がサポートされていない環境があるため、ポリフィルを用意
if (typeof Array.prototype.indexOf !== "function") {
    Array.prototype.indexOf = function(searchElement, fromIndex) {
        var len = this.length >>> 0;
        var from = Number(fromIndex) || 0;
        if (from < 0) {
            from = Math.max(len + from, 0);
        }
        for (var i = from; i < len; i++) {
            if (this[i] === searchElement) {
                return i;
            }
        }
        return -1;
    };
}

var FBJ_TICKS_PER_SECOND = 254016000000;

function fbjumper_callSystem(cmd) {
    try {
        if (typeof system !== "undefined" && typeof system.callSystem === "function") {
            return system.callSystem(cmd);
        }
    } catch (eSys) {
        // ignore
    }
    try {
        if (typeof app !== "undefined" && app.system && typeof app.system.callSystem === "function") {
            return app.system.callSystem(cmd);
        }
    } catch (eApp) {
        // ignore
    }
    return null;
}

function fbjumper_result(ok, message) {
    if (ok) {
        return "OK" + (message ? (": " + message) : "");
    }
    var detail = (typeof message === "string" && message.length) ? message : "Unknown error.";
    return "ERR: " + detail;
}

function fbjumper_enableQE() {
    try {
        if (typeof qe === "undefined") {
            app.enableQE();
        }
        if (typeof qe === "undefined") {
            return fbjumper_result(false, "QE unavailable.");
        }
        return fbjumper_result(true);
    } catch (e) {
        return fbjumper_result(false, e.toString());
    }
}

function fbjumper_getActiveSequence() {
    if (!app.project || !app.project.activeSequence) {
        return null;
    }
    return app.project.activeSequence;
}

function fbjumper_getActiveSequenceInfo() {
    try {
        var activeSeq = fbjumper_getActiveSequence();
        if (!activeSeq) {
            return fbjumper_result(false, "No active sequence.");
        }
        var seqId = "";
        try {
            seqId = activeSeq.sequenceID;
        } catch (eId) {
            seqId = "";
        }
        if (seqId === null || seqId === undefined) {
            seqId = "";
        }
        if (typeof seqId !== "string") {
            seqId = String(seqId);
        }
        var seqName = "";
        try {
            seqName = activeSeq.name || "";
        } catch (eName) {
            seqName = "";
        }
        var encodedName = "";
        try {
            encodedName = encodeURIComponent(seqName);
        } catch (eEnc) {
            encodedName = seqName;
        }
        return "OK:" + seqId + "|" + encodedName;
    } catch (e) {
        return fbjumper_result(false, e.toString());
    }
}

function fbjumper_findSequenceItemByName(name, folder) {
    if (!folder || !folder.children) { return null; }
    for (var i = 0; i < folder.children.length; i += 1) {
        try {
            var item = folder.children[i];
            if (item && item.name === name && item.type === ProjectItemType.SEQUENCE) {
                return item;
            }
            if (item && item.children && item.children.length) {
                var found = fbjumper_findSequenceItemByName(name, item);
                if (found) { return found; }
            }
        } catch (e) {}
    }
    return null;
}

function fbjumper_activateSequence(seqId, seqName) {
    try {
        if (!app.project) {
            return fbjumper_result(false, "No project.");
        }
        var targetId = (seqId !== null && seqId !== undefined) ? String(seqId) : "";
        var targetName = (seqName !== null && seqName !== undefined) ? String(seqName) : "";
        var activeSeq = fbjumper_getActiveSequence();
        if (activeSeq) {
            if (targetId && activeSeq.sequenceID == targetId) {
                return fbjumper_result(true, "already active");
            }
            if (!targetId && targetName && activeSeq.name == targetName) {
                return fbjumper_result(true, "already active");
            }
        }

        if (targetId && typeof app.project.openSequence === "function") {
            try {
                app.project.openSequence(targetId);
            } catch (eOpen) {}
            var afterOpen = fbjumper_getActiveSequence();
            if (afterOpen && ((targetId && afterOpen.sequenceID == targetId) || (targetName && afterOpen.name == targetName))) {
                return fbjumper_result(true, "openSequence");
            }
        }

        if (targetName) {
            var root = app.project.rootItem;
            var seqItem = fbjumper_findSequenceItemByName(targetName, root);
            if (seqItem && typeof seqItem.openInTimeline === "function") {
                seqItem.openInTimeline();
            }
            var afterName = fbjumper_getActiveSequence();
            if (afterName && afterName.name == targetName) {
                return fbjumper_result(true, "openInTimeline");
            }
        }

        return fbjumper_result(false, "Failed to activate sequence.");
    } catch (e) {
        return fbjumper_result(false, e.toString());
    }
}

function fbjumper_jumpTo(ticks) {
    try {
        var activeSeq = fbjumper_getActiveSequence();
        if (!activeSeq) {
            return fbjumper_result(false, "No active sequence.");
        }
        var jumped = false;
        try {
            activeSeq.setPlayerPosition(ticks.toString());
            jumped = true;
        } catch (e1) {
            var qeStatus = fbjumper_enableQE();
            if (qeStatus.indexOf("ERR:") === 0) {
                return fbjumper_result(false, "Standard API failed: " + e1.toString() + ". QE unavailable.");
            }
            try {
                var qeProject = qe.project;
                var qeSequence = qeProject.getActiveSequence();
                if (qeSequence && qeSequence.player) {
                    qeSequence.player.position = ticks;
                    jumped = true;
                }
            } catch (e2) {
                return fbjumper_result(false, "All methods failed. Standard: " + e1.toString() + ", QE: " + e2.toString());
            }
        }
        
        if (jumped) {
            return fbjumper_result(true, "OK");
        }
        return fbjumper_result(false, "No jump method succeeded");
    } catch (e) {
        return fbjumper_result(false, e.toString());
    }
}

function fbjumper_getClipboard() {
    try {
        var command;
        if ($.os && $.os.toLowerCase().indexOf("windows") !== -1) {
            command = 'powershell.exe -NoProfile -NonInteractive -Command "[Console]::OutEncoding=[System.Text.Encoding]::UTF8; Get-Clipboard -Raw"';
	        } else {
	            command = "pbpaste";
	        }
	        var result = fbjumper_callSystem(command);
	        if (typeof result === "string" && result.length > 0) {
	            return result;
	        }
        var tmpFile = new File(Folder.temp + "/fb_jumper_clipboard.txt");
        var cmd;
        if ($.os && $.os.toLowerCase().indexOf("windows") !== -1) {
            cmd = 'cmd.exe /c powershell.exe -NoProfile -NonInteractive -Command "Get-Clipboard | Out-File -Encoding UTF8 \'' + tmpFile.fsName.replace(/\\/g, '\\\\') + '\'"';
        } else {
            cmd = 'pbpaste > "' + tmpFile.fsName + '"';
	        }
	        tmpFile.execute();
	        fbjumper_callSystem(cmd);
	        if (tmpFile.exists) {
	            tmpFile.encoding = "UTF-8";
	            tmpFile.open("r");
            var content = tmpFile.read();
            tmpFile.close();
            tmpFile.remove();
            if (typeof content === "string" && content.length > 0) {
                return content;
            }
        }
        return "ERR: クリップボードにアクセスできません。CEP clipboard APIを使用してください。";
    } catch (e) {
        return "ERR: " + e.toString();
    }
}

function fbjumper_getPlayheadTicks() {
    try {
        var activeSeq = fbjumper_getActiveSequence();
        if (!activeSeq) {
            return fbjumper_result(false, "No active sequence.");
        }
        if (typeof activeSeq.getPlayerPosition === "function") {
            var pos = activeSeq.getPlayerPosition();
            if (pos && typeof pos.ticks !== "undefined") {
                return "OK:" + pos.ticks;
            }
            if (typeof pos === "string" || typeof pos === "number") {
                return "OK:" + pos;
            }
        }
        var qeStatus = fbjumper_enableQE();
        if (qeStatus.indexOf("ERR:") === 0) {
            return fbjumper_result(false, "QE unavailable.");
        }
        if (typeof qe !== "undefined" && qe.project && qe.project.getActiveSequence) {
            var qeSeq = qe.project.getActiveSequence();
            if (qeSeq && qeSeq.player && typeof qeSeq.player.position !== "undefined") {
                return "OK:" + qeSeq.player.position;
            }
        }
        return fbjumper_result(false, "No playhead position available.");
    } catch (e) {
        return fbjumper_result(false, e.toString());
    }
}

function fbjumper_getSelectionRangeTicks() {
    try {
        var activeSeq = fbjumper_getActiveSequence();
        if (!activeSeq) {
            return fbjumper_result(false, "No active sequence.");
        }
        if (typeof activeSeq.getSelection !== "function") {
            return fbjumper_result(false, "Selection unavailable.");
        }
        var selection = activeSeq.getSelection();
        if (!selection || !selection.length) {
            return fbjumper_result(false, "No selection.");
        }
        var minStart = null;
        var maxEnd = null;
        for (var i = 0; i < selection.length; i += 1) {
            try {
                var item = selection[i];
                if (!item || !item.start || item.start.ticks === undefined) { continue; }
                var startTicks = Number(item.start.ticks);
                var endTicks = null;
                if (item.end && item.end.ticks !== undefined) {
                    endTicks = Number(item.end.ticks);
                } else if (item.duration && item.duration.ticks !== undefined) {
                    endTicks = startTicks + Number(item.duration.ticks);
                }
                if (!isNaN(startTicks)) {
                    if (minStart === null || startTicks < minStart) {
                        minStart = startTicks;
                    }
                    if (endTicks !== null && !isNaN(endTicks)) {
                        if (maxEnd === null || endTicks > maxEnd) {
                            maxEnd = endTicks;
                        }
                    }
                }
            } catch (eItem) {}
        }
        if (minStart === null) {
            return fbjumper_result(false, "Selection ticks unavailable.");
        }
        if (maxEnd === null) {
            maxEnd = minStart;
        }
        return "OK:" + minStart + "," + maxEnd;
    } catch (e) {
        return fbjumper_result(false, e.toString());
    }
}

function fbjumper_getSequenceEndTicks() {
    try {
        var activeSeq = fbjumper_getActiveSequence();
        if (!activeSeq) {
            return fbjumper_result(false, "No active sequence.");
        }
        var maxTicks = 0;
        function scanTracks(trackList) {
            if (!trackList || !trackList.numTracks) { return; }
            for (var ti = 0; ti < trackList.numTracks; ti += 1) {
                try {
                    var track = trackList[ti];
                    if (!track || !track.clips || !track.clips.numItems) { continue; }
                    for (var ci = 0; ci < track.clips.numItems; ci += 1) {
                        try {
                            var clip = track.clips[ci];
                            if (!clip || !clip.start || clip.start.ticks === undefined) { continue; }
                            var endTicks = null;
                            if (clip.end && clip.end.ticks !== undefined) {
                                endTicks = Number(clip.end.ticks);
                            } else if (clip.duration && clip.duration.ticks !== undefined) {
                                endTicks = Number(clip.start.ticks) + Number(clip.duration.ticks);
                            }
                            if (endTicks !== null && !isNaN(endTicks) && endTicks > maxTicks) {
                                maxTicks = endTicks;
                            }
                        } catch (eClip) {}
                    }
                } catch (eTrack) {}
            }
        }
        scanTracks(activeSeq.videoTracks);
        scanTracks(activeSeq.audioTracks);
        try {
            if ((!maxTicks || isNaN(maxTicks)) && activeSeq.end && activeSeq.end.ticks !== undefined) {
                maxTicks = Number(activeSeq.end.ticks);
            }
        } catch (eEnd) {}
        return "OK:" + maxTicks;
    } catch (e) {
        return fbjumper_result(false, e.toString());
    }
}

function fbjumper_getPrimaryTrackSnapshot() {
    try {
        var activeSeq = fbjumper_getActiveSequence();
        if (!activeSeq) {
            return fbjumper_result(false, "No active sequence.");
        }
        var blocks = [];
        function collectTracks(trackList, prefix) {
            if (!trackList || !trackList.numTracks) { return; }
            for (var ti = 0; ti < trackList.numTracks; ti += 1) {
                var track = trackList[ti];
                if (!track || !track.clips || !track.clips.numItems) { continue; }
                var parts = [];
                for (var i = 0; i < track.clips.numItems; i += 1) {
                    try {
                        var clip = track.clips[i];
                        if (!clip || !clip.start || clip.start.ticks === undefined) { continue; }
                        var startTicks = Number(clip.start.ticks);
                        var endTicks = null;
                        var inTicks = null;
                        var outTicks = null;
                        if (clip.end && clip.end.ticks !== undefined) {
                            endTicks = Number(clip.end.ticks);
                        } else if (clip.duration && clip.duration.ticks !== undefined) {
                            endTicks = startTicks + Number(clip.duration.ticks);
                        }
                        try {
                            if (clip.inPoint && clip.inPoint.ticks !== undefined) {
                                inTicks = Number(clip.inPoint.ticks);
                            }
                        } catch (eIn) {}
                        try {
                            if (clip.outPoint && clip.outPoint.ticks !== undefined) {
                                outTicks = Number(clip.outPoint.ticks);
                            }
                        } catch (eOut) {}
                        if (isNaN(startTicks) || endTicks === null || isNaN(endTicks)) { continue; }
                        var clipEntry = startTicks + "," + endTicks;
                        if (!isNaN(inTicks) && !isNaN(outTicks)) {
                            clipEntry += "," + inTicks + "," + outTicks;
                        }
                        parts.push(clipEntry);
                    } catch (eClip) {}
                }
                if (parts.length) {
                    blocks.push(prefix + ti + "|" + parts.join(";"));
                }
            }
        }
        collectTracks(activeSeq.videoTracks, "V");
        collectTracks(activeSeq.audioTracks, "A");
        if (!blocks.length) {
            return fbjumper_result(false, "No clips.");
        }
        return "OK:" + blocks.join("||");
    } catch (e) {
        return fbjumper_result(false, e.toString());
    }
}

function fbjumper_getSequenceTimebaseInfo() {
    try {
        var activeSeq = fbjumper_getActiveSequence();
        if (!activeSeq) {
            return fbjumper_result(false, "No active sequence.");
        }
        var fps = 0;
        var ticksPerSecond = FBJ_TICKS_PER_SECOND;
        var ticksPerFrame = null;
        var dropFrame = false;

        try {
            var tb = activeSeq.timebase;
            if (tb) {
                if (tb.ticksPerSecond && (tb.frameDuration || tb.frameTicks)) {
                    ticksPerSecond = Number(tb.ticksPerSecond) || ticksPerSecond;
                    ticksPerFrame = Number(tb.frameDuration || tb.frameTicks);
                    if (ticksPerSecond && ticksPerFrame) {
                        fps = ticksPerSecond / ticksPerFrame;
                    }
                } else if (tb.numerator && tb.denominator) {
                    ticksPerSecond = Number(tb.denominator) || ticksPerSecond;
                    ticksPerFrame = Number(tb.numerator);
                    if (ticksPerSecond && ticksPerFrame) {
                        fps = ticksPerSecond / ticksPerFrame;
                    }
                } else if (tb.num && tb.den) {
                    ticksPerSecond = Number(tb.den) || ticksPerSecond;
                    ticksPerFrame = Number(tb.num);
                    if (ticksPerSecond && ticksPerFrame) {
                        fps = ticksPerSecond / ticksPerFrame;
                    }
                } else if (tb.seconds && tb.seconds > 0) {
                    fps = 1 / tb.seconds;
                } else if (!isNaN(tb) && tb > 0) {
                    fps = 1 / Number(tb);
                }
            }
        } catch (eTb) {}

        try {
            if (activeSeq.getSettings) {
                var settings = activeSeq.getSettings();
                if (settings) {
                    if (settings.videoFrameRate && !isNaN(settings.videoFrameRate)) {
                        fps = Number(settings.videoFrameRate) || fps;
                    } else if (settings.videoFrameDuration && settings.videoFrameDuration.seconds) {
                        fps = 1 / settings.videoFrameDuration.seconds;
                    }
                    var display = null;
                    if (settings.videoDisplayFormat !== undefined && settings.videoDisplayFormat !== null) {
                        display = settings.videoDisplayFormat;
                    } else if (settings.videoTimecodeDisplayFormat !== undefined && settings.videoTimecodeDisplayFormat !== null) {
                        display = settings.videoTimecodeDisplayFormat;
                    }
                    if (display !== null && display !== undefined) {
                        var displayText = display.toString().toLowerCase();
                        if (displayText.indexOf("drop") >= 0 || displayText.indexOf("df") >= 0) {
                            dropFrame = true;
                        }
                    }
                }
            }
        } catch (eSettings) {}

        if ((!fps || fps <= 0) && ticksPerSecond && ticksPerFrame) {
            fps = ticksPerSecond / ticksPerFrame;
        }
        if (!fps || fps <= 0) {
            fps = 30;
        }
        if (!ticksPerFrame) {
            ticksPerFrame = Math.round(ticksPerSecond / fps);
        }

        return "OK:" + fps + "|" + ticksPerSecond + "|" + ticksPerFrame + "|" + (dropFrame ? 1 : 0);
    } catch (e) {
        return fbjumper_result(false, e.toString());
    }
}
