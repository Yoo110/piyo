#!/bin/bash

set -e

echo "========================================="
echo "FB Jumper Installer"
echo "========================================="
echo ""

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
SRC_DIR="$SCRIPT_DIR"
DEST_DIR="$HOME/Library/Application Support/Adobe/CEP/extensions/premiere-fb-jumper"
SYSTEM_DEST_DIR="/Library/Application Support/Adobe/CEP/extensions/premiere-fb-jumper"

if pgrep -f "Adobe Premiere Pro" > /dev/null 2>&1; then
    echo "Premiere Pro is running. Close it and run again." >&2
    exit 1
fi

if [ -d "$DEST_DIR" ]; then
    rm -rf "$DEST_DIR"
fi

if [ -d "$SYSTEM_DEST_DIR" ]; then
    if [ -w "$SYSTEM_DEST_DIR" ]; then
        rm -rf "$SYSTEM_DEST_DIR"
    else
        echo "System install exists: $SYSTEM_DEST_DIR" >&2
        echo "If needed: sudo rm -rf \"$SYSTEM_DEST_DIR\"" >&2
    fi
fi

mkdir -p "$DEST_DIR"

cp -R "$SRC_DIR/CSXS" "$DEST_DIR/"
cp -R "$SRC_DIR/css" "$DEST_DIR/"
cp -R "$SRC_DIR/js" "$DEST_DIR/"
cp -R "$SRC_DIR/lib" "$DEST_DIR/"
cp -R "$SRC_DIR/host" "$DEST_DIR/"
cp "$SRC_DIR/index.html" "$DEST_DIR/index.html"

if [ -f "$SRC_DIR/README.md" ]; then
    cp "$SRC_DIR/README.md" "$DEST_DIR/README.md"
fi
if [ -f "$SRC_DIR/VERSION.txt" ]; then
    cp "$SRC_DIR/VERSION.txt" "$DEST_DIR/VERSION.txt"
fi
if [ -f "$SRC_DIR/使い方.md" ]; then
    cp "$SRC_DIR/使い方.md" "$DEST_DIR/使い方.md"
fi

# Enable CEP debug mode (CSXS 10-13)
defaults write com.adobe.CSXS.13 PlayerDebugMode 1 2>/dev/null || true
defaults write com.adobe.CSXS.12 PlayerDebugMode 1 2>/dev/null || true
defaults write com.adobe.CSXS.11 PlayerDebugMode 1 2>/dev/null || true
defaults write com.adobe.CSXS.10 PlayerDebugMode 1 2>/dev/null || true

echo ""
echo "Install complete."
echo "Restart Premiere Pro and open: Window > Extensions (Legacy) > FB Jumper"
