(function () {
    const TICKS_PER_SECOND = 254016000000;
    const DEFAULT_FPS = 29.97;
    const DEFAULT_TICKS_PER_FRAME = Math.round(TICKS_PER_SECOND / DEFAULT_FPS);
    const timePattern = /(\b\d{1,2}:\d{2}(?::\d{2})?(?:[:;]\d{2})?\b)/;
    const cs = new CSInterface();
    const isMac = navigator.platform ? /mac/i.test(navigator.platform) : false;
    const STORAGE_KEYS = {
        anchors: 'fbj-anchors-v1'
    };

    const fbInput = document.getElementById('fb');
    const parseBtn = document.getElementById('parse');
    const clearBtn = document.getElementById('clear');
    const listEl = document.getElementById('list');
    const anchorListEl = document.getElementById('anchor-list');
    const autoFollowToggle = document.getElementById('auto-follow');
    const autoFollowStatusEl = document.getElementById('auto-follow-status');
    const clearChecksBtn = document.getElementById('clear-checks');
    const clearChecksInlineBtn = document.getElementById('clear-checks-inline');
    const copyListBtn = document.getElementById('copy-list');
    const addEntryBtn = document.getElementById('add-entry');
    const CHECK_KEY_PREFIX = 'fb-check-';
    const STORAGE_AUTO_FOLLOW = 'fbj-auto-follow';
    const AUTO_FOLLOW_POLL_MS = 900;
    const AUTO_FOLLOW_SETTLE_MS = 450;
    const AUTO_FOLLOW_MIN_DELTA_SECONDS = 0.02;
    const AUTO_ANCHOR_TOLERANCE_SECONDS = 0.25;
    const SNAPSHOT_TOLERANCE_SECONDS = 0.25;
    const AUTO_UNDO_TOLERANCE_SECONDS = 0.3;
    const AUTO_FOLLOW_SELECTION_STALE_MS = AUTO_FOLLOW_POLL_MS * 3;

    let currentEntries = [];
    let entryIdCounter = 0;
    let pendingEditEntryId = null;
    let activeEditEntryId = null;
    let activeEditOriginalNote = null;
    let anchors = [];
    let autoFollowEnabled = false;
    let autoFollowTimer = null;
    let autoFollowInFlight = false;
    let lastSequenceEndTicks = null;
    let lastObservedPlayheadTicks = null;
    let lastObservedPlayheadAt = null;
    let lastObservedSelection = null;
    let lastObservedSelectionAt = null;
    let lastTrackSnapshot = null;
    let lastAnchorMeta = null;
    let firstEntryTicks = null;
    let lastAutoAdjustment = null;
    let baselineTrackSnapshot = null;
    let baselineSequenceEndTicks = null;
    let pendingBaselineSnapshot = null;
    let pendingBaselineEndTicks = null;
    let pendingLatestSnapshot = null;
    let pendingLatestEndTicks = null;
    let pendingLastChangeAt = null;
    let currentSequenceInfo = null;
    let timebase = {
        fps: DEFAULT_FPS,
        ticksPerSecond: TICKS_PER_SECOND,
        ticksPerFrame: DEFAULT_TICKS_PER_FRAME,
        dropFrame: false,
        source: 'fallback'
    };

    function setAutoFollowStatus(text) {
        if (!autoFollowStatusEl) {
            return;
        }
        autoFollowStatusEl.textContent = text || '';
    }

    function jsxString(value) {
        const safe = String(value || '')
            .replace(/\\/g, '\\\\')
            .replace(/'/g, "\\'");
        return "'" + safe + "'";
    }

    function parseSequenceInfo(result) {
        if (!result) {
            return { ok: false, error: 'シーケンス情報が空です' };
        }
        if (typeof result === 'string' && result.indexOf('ERR:') === 0) {
            return { ok: false, error: result.replace(/^ERR:\s*/, '') };
        }
        const cleaned = String(result).replace(/^OK[:\s]*/, '');
        const pipeIndex = cleaned.indexOf('|');
        const id = pipeIndex >= 0 ? cleaned.slice(0, pipeIndex).trim() : cleaned.trim();
        let name = pipeIndex >= 0 ? cleaned.slice(pipeIndex + 1) : '';
        if (name) {
            try {
                name = decodeURIComponent(name);
            } catch (e) {
                // ignore decode failure and keep raw
            }
        }
        if (!id && !name) {
            return { ok: false, error: 'シーケンス情報が取得できませんでした' };
        }
        return {
            ok: true,
            id,
            name
        };
    }

    function ensureBoundSequence(callback, options) {
        if (!currentSequenceInfo || (!currentSequenceInfo.id && !currentSequenceInfo.name)) {
            if (typeof callback === 'function') {
                callback(true);
            }
            return;
        }
        const idArg = currentSequenceInfo.id ? jsxString(currentSequenceInfo.id) : 'null';
        const nameArg = currentSequenceInfo.name ? jsxString(currentSequenceInfo.name) : 'null';
        cs.evalScript('fbjumper_activateSequence(' + idArg + ',' + nameArg + ')', function(result) {
            if (typeof result === 'string' && result.indexOf('ERR:') === 0) {
                if (!options || !options.silent) {
                    window.alert('解析時のシーケンスをアクティブにできませんでした。\n\n' + result);
                }
                if (typeof callback === 'function') {
                    callback(false, result);
                }
                return;
            }
            if (typeof callback === 'function') {
                callback(true, result);
            }
        });
    }

    function parseTimebaseResult(result) {
        if (!result) {
            return { ok: false, error: 'シーケンス情報を取得できませんでした' };
        }
        if (typeof result === 'string' && result.indexOf('ERR:') === 0) {
            return { ok: false, error: result.replace(/^ERR:\s*/, '') };
        }
        const cleaned = String(result).replace(/^OK[:\s]*/, '');
        const usesPipe = cleaned.indexOf('|') >= 0;
        let parts = cleaned.split(usesPipe ? '|' : ',').map((part) => part.trim());
        if (!usesPipe && parts.length > 4) {
            const mergedFps = parts[0] + '.' + parts[1];
            if (!Number.isNaN(Number(mergedFps))) {
                parts = [mergedFps, parts[2], parts[3], parts[4]];
            }
        }
        const fps = Number(parts[0]);
        const ticksPerSecond = Number(parts[1]);
        const ticksPerFrame = Number(parts[2]);
        const dropFrame = parts[3] === '1' || parts[3] === 'true';
        const info = {
            fps: isFinite(fps) ? fps : null,
            ticksPerSecond: isFinite(ticksPerSecond) && ticksPerSecond > 0 ? ticksPerSecond : TICKS_PER_SECOND,
            ticksPerFrame: isFinite(ticksPerFrame) && ticksPerFrame > 0 ? ticksPerFrame : null,
            dropFrame: dropFrame,
            source: 'sequence'
        };
        return { ok: true, info };
    }

    function applyTimebase(info) {
        if (!info) {
            return;
        }
        if (typeof info.fps === 'number' && isFinite(info.fps) && info.fps > 0) {
            timebase.fps = info.fps;
        }
        if (typeof info.ticksPerSecond === 'number' && isFinite(info.ticksPerSecond) && info.ticksPerSecond > 0) {
            timebase.ticksPerSecond = info.ticksPerSecond;
        }
        if (typeof info.ticksPerFrame === 'number' && isFinite(info.ticksPerFrame) && info.ticksPerFrame > 0) {
            timebase.ticksPerFrame = info.ticksPerFrame;
        } else if (timebase.fps > 0) {
            timebase.ticksPerFrame = Math.round(timebase.ticksPerSecond / timebase.fps);
        }
        if (typeof info.dropFrame === 'boolean') {
            timebase.dropFrame = info.dropFrame;
        }
        timebase.source = info.source || timebase.source;
    }

    function refreshTimebase(done, options) {
        ensureBoundSequence(function(ready) {
            if (!ready) {
                if (typeof done === 'function') {
                    done({ ok: false, error: 'sequence activation failed' });
                }
                return;
            }
            cs.evalScript('fbjumper_getSequenceTimebaseInfo()', function(result) {
                const parsed = parseTimebaseResult(result);
                if (parsed.ok) {
                    applyTimebase(parsed.info);
                }
                if (typeof done === 'function') {
                    done(parsed);
                }
            });
        }, options);
    }

    function ticksToSeconds(ticks) {
        const base = (timebase && timebase.ticksPerSecond) ? timebase.ticksPerSecond : TICKS_PER_SECOND;
        return ticks / base;
    }

    function secondsToTicks(seconds) {
        const base = (timebase && timebase.ticksPerSecond) ? timebase.ticksPerSecond : TICKS_PER_SECOND;
        return Math.round(seconds * base);
    }

    function truncatedTimecodeFromTicks(ticks) {
        return truncatedTimecode(ticksToSeconds(ticks));
    }

    function formatOffsetTicks(offsetTicks) {
        return formatOffset(ticksToSeconds(offsetTicks));
    }

    function dropFrameTimecodeToFrames(hours, minutes, seconds, frames, fpsNominal) {
        const dropFrames = Math.round(fpsNominal * 0.066666);
        const totalMinutes = (hours * 60) + minutes;
        let totalFrames = ((hours * 3600 + minutes * 60 + seconds) * fpsNominal) + frames;
        totalFrames -= dropFrames * (totalMinutes - Math.floor(totalMinutes / 10));
        return totalFrames;
    }

    function ticksFromTimecode(code) {
        if (!code) {
            return null;
        }
        const trimmed = String(code).trim();
        if (!trimmed) {
            return null;
        }
        const hasDropMarker = trimmed.indexOf(';') >= 0;
        const parts = trimmed.split(/[:;]/);
        if (parts.length < 2 || parts.length > 4) {
            return null;
        }
        const nums = parts.map((part) => Number(part));
        if (nums.some((num) => Number.isNaN(num))) {
            return null;
        }
        let hours = 0;
        let minutes = 0;
        let seconds = 0;
        let frames = null;
        if (parts.length === 2) {
            minutes = nums[0];
            seconds = nums[1];
        } else if (parts.length === 3) {
            if (hasDropMarker) {
                minutes = nums[0];
                seconds = nums[1];
                frames = nums[2];
            } else {
                hours = nums[0];
                minutes = nums[1];
                seconds = nums[2];
            }
        } else {
            hours = nums[0];
            minutes = nums[1];
            seconds = nums[2];
            frames = nums[3];
        }

        const totalSeconds = (hours * 3600) + (minutes * 60) + seconds;
        if (frames === null || frames === undefined) {
            let ticks = secondsToTicks(totalSeconds);
            if (timebase.ticksPerFrame && timebase.ticksPerFrame <= timebase.ticksPerSecond) {
                ticks = Math.round(ticks / timebase.ticksPerFrame) * timebase.ticksPerFrame;
            }
            return ticks;
        }

        const fps = (timebase && timebase.fps) ? timebase.fps : DEFAULT_FPS;
        const fpsNominal = Math.round(fps || DEFAULT_FPS);
        const useDrop = hasDropMarker || (timebase && timebase.dropFrame);
        let totalFrames;
        if (useDrop && (Math.abs(fps - 29.97) < 0.02 || Math.abs(fps - 59.94) < 0.02)) {
            totalFrames = dropFrameTimecodeToFrames(hours, minutes, seconds, frames, fpsNominal);
        } else {
            totalFrames = (totalSeconds * fpsNominal) + frames;
        }
        if (timebase.ticksPerFrame) {
            return Math.round(totalFrames * timebase.ticksPerFrame);
        }
        return Math.round((totalFrames / fpsNominal) * timebase.ticksPerSecond);
    }

    function secondsToTimecode(totalSeconds) {
        const safeSeconds = Math.max(0, Number(totalSeconds) || 0);
        const totalMs = Math.round(safeSeconds * 1000);
        const seconds = Math.floor(totalMs / 1000);
        const ms = totalMs % 1000;
        const h = Math.floor(seconds / 3600);
        const m = Math.floor((seconds % 3600) / 60);
        const s = seconds % 60;
        const base = (h > 0)
            ? `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
            : `${m}:${String(s).padStart(2, '0')}`;
        if (ms) {
            return `${base}.${String(Math.floor(ms / 10)).padStart(2, '0')}`;
        }
        return base;
    }

    function truncatedTimecode(totalSeconds) {
        const safeSeconds = Math.max(0, Math.floor(Number(totalSeconds) || 0));
        const h = Math.floor(safeSeconds / 3600);
        const m = Math.floor((safeSeconds % 3600) / 60);
        const s = safeSeconds % 60;
        return (h > 0)
            ? `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
            : `${m}:${String(s).padStart(2, '0')}`;
    }

    function formatOffset(offsetSeconds) {
        const sign = offsetSeconds >= 0 ? '+' : '-';
        return sign + truncatedTimecode(Math.abs(offsetSeconds)).replace(/^0:/, '');
    }

    function handleResult(result) {
        console.log('[FB Jumper] handleResult called with:', result);
        if (typeof result === 'string') {
            if (result.indexOf('ERR:') === 0) {
                window.alert('FB Jumper エラー\n\n' + result);
            } else if (result === 'OK') {
                // シンプルなOKは何も表示しない
                console.log('[FB Jumper] Success:', result);
            } else if (result.indexOf('Jumped') >= 0) {
                // ジャンプ成功の詳細情報を表示（デバッグ用）
                console.log('[FB Jumper] Jump details:', result);
                // 必要に応じてアラート表示（デバッグ時のみ）
                // window.alert('ジャンプ成功\n\n' + result);
            } else if (result.indexOf('Failed') >= 0) {
                // ジャンプ失敗の詳細を表示
                window.alert('ジャンプ失敗\n\n' + result);
            } else {
                // その他のメッセージ
                console.log('[FB Jumper] Info:', result);
            }
        }
    }

    function createEntryId() {
        entryIdCounter += 1;
        return 'fbj-entry-' + Date.now() + '-' + entryIdCounter;
    }

    function normalizeEntries(entries, source) {
        return entries.map((entry) => {
            return {
                ...entry,
                id: createEntryId(),
                source: source || entry.source || 'parsed'
            };
        });
    }

    function findEntryById(entryId) {
        if (!entryId) {
            return null;
        }
        for (let i = 0; i < currentEntries.length; i += 1) {
            if (currentEntries[i].id === entryId) {
                return currentEntries[i];
            }
        }
        return null;
    }

    function sortEntriesInPlace(entries) {
        entries.sort((a, b) => {
            if (a.ticks !== b.ticks) {
                return a.ticks - b.ticks;
            }
            const aStamp = a.timestamp || '';
            const bStamp = b.timestamp || '';
            if (aStamp !== bStamp) {
                return aStamp.localeCompare(bStamp);
            }
            const aId = a.id || '';
            const bId = b.id || '';
            return aId.localeCompare(bId);
        });
    }

    function updateFirstEntryTicks() {
        if (!currentEntries.length) {
            firstEntryTicks = null;
            return;
        }
        let parsedMin = null;
        let overallMin = null;
        let hasParsed = false;
        currentEntries.forEach((entry) => {
            if (!isFinite(entry.ticks)) {
                return;
            }
            if (overallMin === null || entry.ticks < overallMin) {
                overallMin = entry.ticks;
            }
            if (entry.source === 'parsed') {
                hasParsed = true;
                if (parsedMin === null || entry.ticks < parsedMin) {
                    parsedMin = entry.ticks;
                }
            }
        });
        firstEntryTicks = hasParsed ? parsedMin : overallMin;
    }

    function extractEntries(text) {
        const lines = text.split(/\r?\n/);
        const entries = [];

        for (let i = 0; i < lines.length; i += 1) {
            const line = lines[i];
            const match = line.match(timePattern);
            if (!match) {
                continue;
            }
            const timestamp = match[1];
            const ticks = ticksFromTimecode(timestamp);
            if (Number.isNaN(ticks) || ticks === null) {
                continue;
            }

            const matchIndex = match.index || 0;
            let remainder = line.slice(matchIndex + timestamp.length).trim();
            const noteParts = [];
            if (remainder) {
                noteParts.push(remainder);
            }

            let j = i + 1;
            while (j < lines.length) {
                const nextLine = lines[j];
                const trimmed = nextLine.trim();
                if (!trimmed) {
                    j += 1;
                    break;
                }
                const nextMatch = trimmed.match(timePattern);
                if (nextMatch && (nextMatch.index || 0) === 0) {
                    break;
                }
                noteParts.push(trimmed);
                j += 1;
            }

            if (j > i + 1) {
                i = j - 1;
            }

            entries.push({
                timestamp,
                ticks,
                note: noteParts.join(' ')
            });
        }

        return entries.sort((a, b) => a.ticks - b.ticks);
    }

    function applyAnchorsToEntries(entries) {
        if (!anchors.length) {
            return entries.map((entry) => ({
                ...entry,
                adjustedTicks: entry.ticks,
                offsetTicks: 0
            }));
        }

        let anchorIndex = 0;
        let applicable = null;
        return entries.map((entry) => {
            while (anchorIndex < anchors.length && anchors[anchorIndex].sourceTicks <= entry.ticks) {
                applicable = anchors[anchorIndex];
                anchorIndex += 1;
            }
            const offsetTicks = applicable ? applicable.offsetTicks : 0;
            const adjustedTicks = Math.max(0, entry.ticks + offsetTicks);
            return {
                ...entry,
                adjustedTicks,
                offsetTicks
            };
        });
    }

    function getOffsetForSourceTicks(sourceTicks) {
        if (!anchors.length) {
            return 0;
        }
        let offset = 0;
        for (let i = 0; i < anchors.length; i += 1) {
            if (anchors[i].sourceTicks <= sourceTicks) {
                offset = anchors[i].offsetTicks;
            } else {
                break;
            }
        }
        return offset;
    }

    function findSourceTicksForTarget(targetTicks) {
        if (!anchors.length || typeof targetTicks !== 'number' || !isFinite(targetTicks)) {
            return targetTicks;
        }
        const toleranceTicks = secondsToTicks(AUTO_ANCHOR_TOLERANCE_SECONDS);
        let prevSource = 0;
        let prevOffset = 0;
        for (let i = 0; i < anchors.length; i += 1) {
            const anchor = anchors[i];
            const nextSource = anchor.sourceTicks;
            const targetStart = prevSource + prevOffset;
            const targetEnd = nextSource + prevOffset;
            if (targetTicks >= targetStart - toleranceTicks && targetTicks < targetEnd + toleranceTicks) {
                return targetTicks - prevOffset;
            }
            prevSource = anchor.sourceTicks;
            prevOffset = anchor.offsetTicks;
        }
        return targetTicks - prevOffset;
    }

    function findAnchorIndexAtSource(sourceTicks) {
        const toleranceTicks = secondsToTicks(AUTO_ANCHOR_TOLERANCE_SECONDS);
        for (let i = 0; i < anchors.length; i += 1) {
            if (Math.abs(anchors[i].sourceTicks - sourceTicks) <= toleranceTicks) {
                return i;
            }
        }
        return -1;
    }

    function getActiveEditorState() {
        const noteEl = document.querySelector('.note.editing');
        if (!noteEl) {
            return null;
        }
        const editor = noteEl.querySelector('.note-editor');
        if (!editor) {
            return null;
        }
        const entryId = noteEl.dataset.entryId || null;
        const entry = entryId ? findEntryById(entryId) : null;
        const noteTextEl = noteEl.querySelector('.note-text');
        const metaEl = noteEl.querySelector('.note-meta');
        return { noteEl, editor, entryId, entry, noteTextEl, metaEl };
    }

    function syncEditingNotes() {
        const active = getActiveEditorState();
        if (!active || !active.entry) {
            return;
        }
        active.entry.note = active.editor.value;
    }

    function commitActiveEdit() {
        const active = getActiveEditorState();
        if (!active || !active.entry) {
            activeEditEntryId = null;
            activeEditOriginalNote = null;
            return;
        }
        active.entry.note = active.editor.value.trim();
        if (active.noteTextEl) {
            active.noteTextEl.textContent = active.entry.note || '';
            active.noteTextEl.style.display = '';
        }
        if (active.metaEl) {
            active.metaEl.style.display = '';
        }
        active.noteEl.classList.remove('editing');
        if (active.editor.parentNode === active.noteEl) {
            active.noteEl.removeChild(active.editor);
        }
        if (activeEditEntryId === active.entry.id) {
            activeEditEntryId = null;
            activeEditOriginalNote = null;
        }
    }

    function startNoteEdit(entry, noteEl, noteTextEl, metaEl) {
        if (!noteEl || noteEl.classList.contains('editing')) {
            return;
        }
        const entryId = entry && entry.id ? entry.id : null;
        const active = getActiveEditorState();
        if (active && active.entryId && entryId && active.entryId !== entryId) {
            commitActiveEdit();
        }
        const hasStoredOriginal = entryId && activeEditEntryId === entryId && activeEditOriginalNote !== null;
        const originalNote = hasStoredOriginal ? activeEditOriginalNote : (entry.note || '');
        if (entryId && !hasStoredOriginal) {
            activeEditEntryId = entryId;
            activeEditOriginalNote = originalNote;
        }
        noteEl.classList.add('editing');
        const editor = document.createElement('textarea');
        editor.className = 'note-editor';
        editor.value = entry.note || '';
        noteEl.appendChild(editor);
        if (noteTextEl) {
            noteTextEl.style.display = 'none';
        }
        if (metaEl) {
            metaEl.style.display = 'none';
        }
        editor.focus();
        try {
            editor.setSelectionRange(editor.value.length, editor.value.length);
        } catch (e) {
            // ignore
        }

        const finish = (apply) => {
            if (!noteEl.classList.contains('editing')) {
                return;
            }
            if (apply) {
                entry.note = editor.value.trim();
            } else {
                entry.note = originalNote || '';
            }
            if (noteTextEl) {
                noteTextEl.textContent = entry.note || '';
                noteTextEl.style.display = '';
            }
            if (metaEl) {
                metaEl.style.display = '';
            }
            editor.removeEventListener('blur', onBlur);
            editor.removeEventListener('keydown', onKeydown);
            editor.removeEventListener('input', onInput);
            editor.removeEventListener('click', onClick);
            noteEl.classList.remove('editing');
            if (editor.parentNode === noteEl) {
                noteEl.removeChild(editor);
            }
            if (entryId && activeEditEntryId === entryId) {
                activeEditEntryId = null;
                activeEditOriginalNote = null;
            }
        };

        const onBlur = () => finish(true);
        const onKeydown = (event) => {
            if (event.key === 'Escape') {
                event.preventDefault();
                finish(false);
            } else if (event.key === 'Enter' && (event.metaKey || event.ctrlKey)) {
                event.preventDefault();
                finish(true);
            }
        };
        const onInput = () => {
            entry.note = editor.value;
        };
        const onClick = (event) => {
            event.stopPropagation();
        };

        editor.addEventListener('blur', onBlur);
        editor.addEventListener('keydown', onKeydown);
        editor.addEventListener('input', onInput);
        editor.addEventListener('click', onClick);
    }

    function renderList(entries) {
        syncEditingNotes();
        listEl.innerHTML = '';
        if (!entries.length) {
            const empty = document.createElement('div');
            empty.className = 'result-row';
            empty.textContent = '解析結果はありません';
            listEl.appendChild(empty);
            return;
        }

        entries.forEach((entry) => {
            const entryRef = entry.id ? findEntryById(entry.id) : entry;
            const entryId = entryRef && entryRef.id ? entryRef.id : entry.id;
            const noteValue = entryRef && typeof entryRef.note === 'string' ? entryRef.note : (entry.note || '');
            const adjustedTicks = typeof entry.adjustedTicks === 'number'
                ? entry.adjustedTicks
                : entry.ticks;
            const offsetTicks = typeof entry.offsetTicks === 'number'
                ? entry.offsetTicks
                : 0;
            const displayTime = truncatedTimecodeFromTicks(adjustedTicks);

            const row = document.createElement('div');
            row.className = 'result-row';
            if (entryId) {
                row.dataset.entryId = entryId;
            }

            const timeBtn = document.createElement('button');
            timeBtn.className = 'time-button';
            timeBtn.textContent = displayTime;
            timeBtn.addEventListener('click', () => {
                const ticks = Math.round(adjustedTicks);
                console.log('[FB Jumper] Jumping to:', entry.timestamp, 'adjusted:', displayTime, 'ticks:', ticks);

                // ボタンの状態を「処理中」に
                const originalText = timeBtn.textContent;
                timeBtn.textContent = '...';
                timeBtn.disabled = true;

                ensureBoundSequence(function(ready) {
                    if (!ready) {
                        timeBtn.textContent = originalText;
                        timeBtn.disabled = false;
                        return;
                    }
                    cs.evalScript('fbjumper_jumpTo(' + ticks + ')', function(result) {
                        console.log('[FB Jumper] Jump result:', result);

                        // ボタンの状態を元に戻す
                        timeBtn.textContent = originalText;
                        timeBtn.disabled = false;
                        // ボタンのフォーカスを外してパネルへのフォーカス戻りを防ぐ
                        try { timeBtn.blur(); } catch (eBlur) {}

                        // 結果に応じて視覚的フィードバック
                        if (result && (result === 'OK' || result.indexOf('Jumped') >= 0)) {
                            // 成功：緑色に一瞬光らせる
                            timeBtn.style.backgroundColor = '#10b981';
                            setTimeout(() => {
                                timeBtn.style.backgroundColor = '';
                            }, 500);
                        } else if (result && result.indexOf('ERR:') === 0) {
                            // エラー：赤色に一瞬光らせる
                            timeBtn.style.backgroundColor = '#ef4444';
                            setTimeout(() => {
                                timeBtn.style.backgroundColor = '';
                            }, 500);
                        }

                        handleResult(result);

                    });
                });
            });

            const note = document.createElement('div');
            note.className = 'note';
            if (entryId) {
                note.dataset.entryId = entryId;
            }
            const noteText = document.createElement('div');
            noteText.className = 'note-text';
            noteText.textContent = noteValue || '';
            note.appendChild(noteText);

            let meta = null;
            if (offsetTicks !== 0) {
                meta = document.createElement('div');
                meta.className = 'note-meta';
                meta.textContent = `元 ${entry.timestamp} / 補正 ${formatOffsetTicks(offsetTicks)}`;
                note.appendChild(meta);
            }

            note.addEventListener('click', () => {
                if (entryRef) {
                    startNoteEdit(entryRef, note, noteText, meta);
                }
            });

            const checkBtn = document.createElement('button');
            checkBtn.className = 'check-button';
            checkBtn.innerHTML = ''; // 初期状態は空
            checkBtn.title = '対応済みにする';
            
            // ローカルストレージから状態を復元
            const entryKey = entryId ? entryId : entry.timestamp + '-' + noteValue;
            const storageKey = CHECK_KEY_PREFIX + entryKey;
            const isChecked = localStorage.getItem(storageKey) === 'true';
            if (isChecked) {
                checkBtn.classList.add('checked');
                checkBtn.innerHTML = '✓';
            }
            
            checkBtn.addEventListener('click', () => {
                // チェック状態をトグル
                if (checkBtn.classList.contains('checked')) {
                    // チェックを外す
                    checkBtn.classList.remove('checked');
                    checkBtn.innerHTML = '';
                    localStorage.removeItem(storageKey);
                } else {
                    // チェックを入れる
                    checkBtn.classList.add('checked');
                    checkBtn.innerHTML = '✓';
                    localStorage.setItem(storageKey, 'true');
                }
            });

            row.appendChild(timeBtn);
            row.appendChild(note);
            row.appendChild(checkBtn);
            listEl.appendChild(row);

            let shouldEdit = false;
            if (pendingEditEntryId && entryId && entryId === pendingEditEntryId) {
                pendingEditEntryId = null;
                activeEditEntryId = entryId;
                shouldEdit = true;
            } else if (activeEditEntryId && entryId && entryId === activeEditEntryId) {
                shouldEdit = true;
            }
            if (shouldEdit && entryRef) {
                startNoteEdit(entryRef, note, noteText, meta);
            }
        });
    }

    function buildCopyText(entries) {
        if (!entries || !entries.length) {
            return '';
        }
        const adjustedEntries = applyAnchorsToEntries(entries);
        return adjustedEntries.map((entry) => {
            const adjustedTicks = typeof entry.adjustedTicks === 'number'
                ? entry.adjustedTicks
                : entry.ticks;
            const displayTime = truncatedTimecodeFromTicks(adjustedTicks);
            const note = (entry.note || '').trim();
            return note ? `${displayTime} ${note}` : displayTime;
        }).join('\n');
    }

    function addManualEntryAtTicks(ticks) {
        if (!isFinite(ticks)) {
            return null;
        }
        const entry = {
            id: createEntryId(),
            timestamp: truncatedTimecodeFromTicks(ticks),
            ticks,
            note: '',
            source: 'manual'
        };
        currentEntries.push(entry);
        sortEntriesInPlace(currentEntries);
        updateFirstEntryTicks();
        pendingEditEntryId = entry.id;
        refreshList();
        return entry;
    }

    function addEntryFromPlayhead() {
        commitActiveEdit();
        refreshTimebase((parsed) => {
            if (parsed && parsed.ok === false) {
                return;
            }
            cs.evalScript('fbjumper_getPlayheadTicks()', function(result) {
                const parsed = parsePlayheadResult(result);
                if (!parsed.ok) {
                    handleResult('ERR: ' + (parsed.error || '再生位置を取得できませんでした'));
                    return;
                }
                addManualEntryAtTicks(parsed.ticks);
            });
        });
    }

    function copyTextToClipboard(text, done) {
        if (!text) {
            if (typeof done === 'function') {
                done(false);
            }
            return;
        }
        const fallback = () => {
            let success = false;
            try {
                const area = document.createElement('textarea');
                area.value = text;
                area.setAttribute('readonly', 'readonly');
                area.style.position = 'fixed';
                area.style.opacity = '0';
                area.style.left = '-9999px';
                document.body.appendChild(area);
                area.focus();
                area.select();
                area.setSelectionRange(0, area.value.length);
                success = document.execCommand('copy');
                document.body.removeChild(area);
            } catch (e) {
                success = false;
            }
            if (typeof done === 'function') {
                done(success);
            }
        };
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text)
                .then(() => {
                    if (typeof done === 'function') {
                        done(true);
                    }
                })
                .catch(fallback);
            return;
        }
        fallback();
    }

    function clearAllChecks() {
        try {
            const keys = [];
            for (let i = 0; i < localStorage.length; i += 1) {
                const k = localStorage.key(i);
                if (k && k.indexOf(CHECK_KEY_PREFIX) === 0) {
                    keys.push(k);
                }
            }
            keys.forEach((k) => localStorage.removeItem(k));
        } catch (e) {
            console.log('[FB Jumper] clear checks failed', e);
        }
        try {
            document.querySelectorAll('.check-button').forEach((btn) => {
                btn.classList.remove('checked');
                btn.innerHTML = '';
            });
        } catch (e2) {
            console.log('[FB Jumper] clear checks UI update failed', e2);
        }
    }

    parseBtn.addEventListener('click', () => {
        const text = fbInput.value || '';
        cs.evalScript('fbjumper_getActiveSequenceInfo()', function(result) {
            const parsed = parseSequenceInfo(result);
            if (!parsed.ok) {
                window.alert('解析対象のシーケンスを取得できませんでした。\nシーケンスをアクティブにしてから解析してください。\n\n詳細: ' + (parsed.error || result));
                return;
            }
            currentSequenceInfo = { id: parsed.id, name: parsed.name };
            refreshTimebase((timebaseResult) => {
                if (timebaseResult && timebaseResult.ok === false) {
                    return;
                }
                currentEntries = normalizeEntries(extractEntries(text), 'parsed');
                sortEntriesInPlace(currentEntries);
                updateFirstEntryTicks();
                pendingEditEntryId = null;
                activeEditEntryId = null;
                activeEditOriginalNote = null;
                lastAutoAdjustment = null;
                baselineTrackSnapshot = null;
                baselineSequenceEndTicks = null;
                resetPendingBatch();
                renderList(applyAnchorsToEntries(currentEntries));
                renderAnchors();
            });
        });
    });

    // ペーストイベントハンドラー（シンプル版）
    function handlePaste(event) {
        console.log('[FB Jumper] Paste event triggered');
        
        // event.clipboardDataから取得を試みる（最も確実な方法）
        const clipboard = event.clipboardData || window.clipboardData;
        if (clipboard) {
            const text = clipboard.getData('text/plain') || clipboard.getData('text') || clipboard.getData('Text');
            console.log('[FB Jumper] clipboardData result:', text);
            
            if (text && text.length) {
                // デフォルトのペースト動作を防止して、手動で挿入
                event.preventDefault();
                
                const start = fbInput.selectionStart;
                const end = fbInput.selectionEnd;
                const before = fbInput.value.slice(0, start);
                const after = fbInput.value.slice(end);
                
                fbInput.value = before + text + after;
                const newPosition = start + text.length;
                fbInput.setSelectionRange(newPosition, newPosition);
                fbInput.focus();
                
                console.log('[FB Jumper] Paste successful!');
                return;
            }
        }
        
        // clipboardDataが取得できない場合は、デフォルトのペースト動作を許可
        console.log('[FB Jumper] Using default paste behavior');
    }

    // Cmd+V / Ctrl+V のキーボードショートカット
    function handleKeyDown(event) {
        const modifier = isMac ? event.metaKey : event.ctrlKey;
        const isVKey = event.key === 'v' || event.key === 'V' || event.keyCode === 86;
        
        if (modifier && isVKey) {
            console.log('[FB Jumper] Cmd+V / Ctrl+V detected in keydown');
            // pasteイベントを待つ
            // フォーカスを確保
            fbInput.focus();
            return;
        }
    }

    // document全体でCmd+Vを捕捉（Premiereがキーを取る前に）
    document.addEventListener('keydown', function(event) {
        const modifier = isMac ? event.metaKey : event.ctrlKey;
        const isVKey = event.key === 'v' || event.key === 'V' || event.keyCode === 86;
        
        if (modifier && isVKey) {
            console.log('[FB Jumper] Cmd+V detected on document level');
            // textareaにフォーカスを当てる
            fbInput.focus();
            // pasteイベントが発火するのを待つ
            return;
        }

    }, true); // キャプチャフェーズで捕捉

    // イベントリスナーを登録
    fbInput.addEventListener('paste', handlePaste);
    fbInput.addEventListener('keydown', handleKeyDown);
    
    // textareaにフォーカスを当てて、確実にイベントを受け取れるようにする
    fbInput.addEventListener('focus', function() {
        console.log('[FB Jumper] Textarea focused');
    });
    
    // textareaをクリックしたときに確実にフォーカスを当てる
    fbInput.addEventListener('click', function() {
        fbInput.focus();
        console.log('[FB Jumper] Textarea clicked and focused');
    });

    // パネルがアクティブになったときにフォーカスを戻す
    document.addEventListener('visibilitychange', function() {
        if (!document.hidden) {
            setTimeout(function() {
                fbInput.focus();
                console.log('[FB Jumper] Panel became visible, focus restored');
            }, 100);
        }
    });

    clearBtn.addEventListener('click', () => {
        fbInput.value = '';
        listEl.innerHTML = '';
        currentEntries = [];
        firstEntryTicks = null;
        pendingEditEntryId = null;
        activeEditEntryId = null;
        activeEditOriginalNote = null;
        lastAutoAdjustment = null;
        baselineTrackSnapshot = null;
        baselineSequenceEndTicks = null;
        currentSequenceInfo = null;
        resetPendingBatch();
    });

    // 初期化時にtextareaにフォーカスを当てる
    setTimeout(function() {
        fbInput.focus();
        console.log('[FB Jumper] Initial focus set to textarea');
    }, 300);

    function persistAnchors() {
        try {
            // 過去の補正ログを残さない方針
            localStorage.removeItem(STORAGE_KEYS.anchors);
        } catch (e) {
            console.log('[FB Jumper] anchor persist failed', e);
        }
    }

    function loadAnchors() {
        anchors = [];
        lastAnchorMeta = null;
        lastAutoAdjustment = null;
        try {
            localStorage.removeItem(STORAGE_KEYS.anchors);
        } catch (e) {
            console.log('[FB Jumper] anchor clear failed', e);
        }
    }

    function renderAnchors() {
        if (!anchorListEl) {
            return;
        }
        anchorListEl.innerHTML = '';
        if (!lastAnchorMeta && !anchors.length) {
            const empty = document.createElement('div');
            empty.className = 'anchor-pill';
            empty.textContent = '補正点はまだありません';
            anchorListEl.appendChild(empty);
            return;
        }
        const pill = document.createElement('div');
        pill.className = 'anchor-pill';

        const label = document.createElement('div');
        const hasBaseTicks = typeof firstEntryTicks === 'number' && isFinite(firstEntryTicks);
        if (typeof firstEntryTicks === 'number' && isFinite(firstEntryTicks)) {
            label.innerHTML = `<strong>基準 ${truncatedTimecodeFromTicks(firstEntryTicks)}</strong>`;
        } else {
            label.innerHTML = '<strong>基準</strong>';
        }

        const offset = document.createElement('div');
        let offsetTicks = 0;
        if (hasBaseTicks) {
            offsetTicks = getOffsetForSourceTicks(firstEntryTicks);
        } else if (lastAnchorMeta && typeof lastAnchorMeta.offsetTicks === 'number') {
            offsetTicks = lastAnchorMeta.offsetTicks;
        }
        offset.className = 'anchor-offset ' + (offsetTicks >= 0 ? 'positive' : 'negative');
        offset.textContent = `差分 ${formatOffsetTicks(offsetTicks)}`;

        pill.appendChild(label);
        pill.appendChild(offset);
        anchorListEl.appendChild(pill);
    }

    function refreshList() {
        renderList(applyAnchorsToEntries(currentEntries));
    }

    if (addEntryBtn) {
        addEntryBtn.addEventListener('click', () => {
            addEntryFromPlayhead();
        });
    }

    if (clearChecksBtn) {
        clearChecksBtn.addEventListener('click', () => {
            clearAllChecks();
        });
    }
    if (clearChecksInlineBtn) {
        clearChecksInlineBtn.addEventListener('click', () => {
            clearAllChecks();
        });
    }
    if (copyListBtn) {
        copyListBtn.addEventListener('click', () => {
            const text = buildCopyText(currentEntries);
            const originalText = copyListBtn.textContent;
            if (!text) {
                copyListBtn.textContent = '空です';
                copyListBtn.disabled = true;
                setTimeout(() => {
                    copyListBtn.textContent = originalText;
                    copyListBtn.disabled = false;
                }, 900);
                return;
            }
            copyListBtn.textContent = 'コピー中...';
            copyListBtn.disabled = true;
            copyTextToClipboard(text, (ok) => {
                copyListBtn.textContent = ok ? 'コピー完了' : 'コピー失敗';
                setTimeout(() => {
                    copyListBtn.textContent = originalText;
                    copyListBtn.disabled = false;
                }, 1200);
            });
        });
    }

    function parseTicksResult(result, fallbackError) {
        if (!result) {
            return { ok: false, error: fallbackError || '値を取得できませんでした' };
        }
        if (typeof result === 'string' && result.indexOf('ERR:') === 0) {
            return { ok: false, error: result.replace(/^ERR:\s*/, '') };
        }
        const cleaned = String(result).replace(/^OK[:\s]*/, '');
        const ticks = Number(cleaned);
        if (Number.isNaN(ticks)) {
            return { ok: false, error: fallbackError || '値が不明です' };
        }
        const seconds = ticksToSeconds(ticks);
        return { ok: true, ticks, seconds };
    }

    function parsePlayheadResult(result) {
        return parseTicksResult(result, '再生位置を取得できませんでした');
    }

    function parseSequenceEndResult(result) {
        return parseTicksResult(result, 'シーケンス長を取得できませんでした');
    }

    function parseSelectionRangeResult(result) {
        if (!result) {
            return { ok: false, error: '選択範囲を取得できませんでした' };
        }
        if (typeof result === 'string' && result.indexOf('ERR:') === 0) {
            return { ok: false, error: result.replace(/^ERR:\s*/, '') };
        }
        const cleaned = String(result).replace(/^OK[:\s]*/, '');
        const parts = cleaned.split(/[^0-9]+/).filter((p) => p.length);
        if (parts.length < 1) {
            return { ok: false, error: '選択範囲の値が不明です' };
        }
        const startTicks = Number(parts[0]);
        const endTicks = parts.length > 1 ? Number(parts[1]) : startTicks;
        if (Number.isNaN(startTicks) || Number.isNaN(endTicks)) {
            return { ok: false, error: '選択範囲の値が不明です' };
        }
        return {
            ok: true,
            startTicks,
            endTicks,
            startSeconds: ticksToSeconds(startTicks),
            endSeconds: ticksToSeconds(endTicks)
        };
    }

    function parseTrackSnapshotResult(result) {
        if (!result) {
            return { ok: false, error: 'トラック情報を取得できませんでした' };
        }
        if (typeof result === 'string' && result.indexOf('ERR:') === 0) {
            return { ok: false, error: result.replace(/^ERR:\s*/, '') };
        }
        const cleaned = String(result).replace(/^OK[:\s]*/, '');
        if (!cleaned) {
            return { ok: false, error: 'トラック情報が空です' };
        }
        const blocks = cleaned.split('||').filter((block) => block.trim().length);
        const tracks = [];
        blocks.forEach((block, index) => {
            const sections = block.split('|');
            let payload = block;
            let label = null;
            if (sections.length > 1) {
                label = sections[0];
                payload = sections.slice(1).join('|');
            }
            const clips = [];
            payload.split(';').forEach((chunk) => {
                const trimmed = chunk.trim();
                if (!trimmed) {
                    return;
                }
                const parts = trimmed.split(',');
                if (parts.length < 2) {
                    return;
                }
                const startTicks = Number(parts[0]);
                const endTicks = Number(parts[1]);
                const inTicks = parts.length >= 4 ? Number(parts[2]) : null;
                const outTicks = parts.length >= 4 ? Number(parts[3]) : null;
                if (!isFinite(startTicks) || !isFinite(endTicks)) {
                    return;
                }
                const clipData = {
                    startTicks,
                    endTicks,
                    durationTicks: endTicks - startTicks
                };
                if (isFinite(inTicks)) {
                    clipData.inTicks = inTicks;
                }
                if (isFinite(outTicks)) {
                    clipData.outTicks = outTicks;
                }
                clips.push(clipData);
            });
            if (clips.length) {
                tracks.push({
                    label: label || `T${index}`,
                    clips
                });
            }
        });
        if (!tracks.length) {
            return { ok: false, error: 'トラック情報が空です' };
        }
        return { ok: true, tracks };
    }

    function fetchTrackSnapshot(done) {
        cs.evalScript('fbjumper_getPrimaryTrackSnapshot()', function(result) {
            const parsed = parseTrackSnapshotResult(result);
            if (typeof done === 'function') {
                done(parsed);
            }
        });
    }

    function updateTrackSnapshot(done) {
        fetchTrackSnapshot(function(parsed) {
            if (parsed.ok) {
                lastTrackSnapshot = parsed.tracks;
            }
            if (typeof done === 'function') {
                done(parsed);
            }
        });
    }

    function resetPendingBatch() {
        pendingBaselineSnapshot = null;
        pendingBaselineEndTicks = null;
        pendingLatestSnapshot = null;
        pendingLatestEndTicks = null;
        pendingLastChangeAt = null;
    }

    function hasPendingBatch() {
        return pendingLastChangeAt !== null;
    }

    function startPendingBatch(baselineSnapshot, baselineEndTicks) {
        pendingBaselineSnapshot = baselineSnapshot;
        pendingBaselineEndTicks = baselineEndTicks;
        pendingLatestSnapshot = baselineSnapshot;
        pendingLatestEndTicks = baselineEndTicks;
        pendingLastChangeAt = Date.now();
    }

    function updatePendingBatch(latestSnapshot, latestEndTicks) {
        pendingLatestSnapshot = latestSnapshot;
        pendingLatestEndTicks = latestEndTicks;
        pendingLastChangeAt = Date.now();
    }

    function isPendingBatchSettled() {
        return pendingLastChangeAt !== null
            && (Date.now() - pendingLastChangeAt) >= AUTO_FOLLOW_SETTLE_MS;
    }

    function findClipByStart(sortedClips, startTicks, toleranceTicks) {
        if (!sortedClips || !sortedClips.length) {
            return null;
        }
        let low = 0;
        let high = sortedClips.length - 1;
        while (low <= high) {
            const mid = Math.floor((low + high) / 2);
            const midStart = sortedClips[mid].startTicks;
            if (midStart < startTicks) {
                low = mid + 1;
            } else if (midStart > startTicks) {
                high = mid - 1;
            } else {
                return sortedClips[mid];
            }
        }
        let candidate = null;
        let bestDiff = Infinity;
        if (low < sortedClips.length) {
            const diff = Math.abs(sortedClips[low].startTicks - startTicks);
            if (diff < bestDiff) {
                bestDiff = diff;
                candidate = sortedClips[low];
            }
        }
        if (low > 0) {
            const diff = Math.abs(sortedClips[low - 1].startTicks - startTicks);
            if (diff < bestDiff) {
                bestDiff = diff;
                candidate = sortedClips[low - 1];
            }
        }
        if (candidate && bestDiff <= toleranceTicks) {
            return candidate;
        }
        return null;
    }

    function detectStartCutAtZero(prevSorted, nextSorted, deltaTicks, toleranceTicks) {
        if (deltaTicks >= 0) {
            return null;
        }
        if (!prevSorted.length || !nextSorted.length) {
            return null;
        }
        const prevFirst = prevSorted[0];
        if (!prevFirst || !isFinite(prevFirst.startTicks)) {
            return null;
        }
        if (Math.abs(prevFirst.startTicks) > toleranceTicks) {
            return null;
        }
        const nextFirst = findClipByStart(nextSorted, 0, toleranceTicks);
        if (!nextFirst) {
            return null;
        }
        if (isFinite(prevFirst.inTicks) && isFinite(nextFirst.inTicks)) {
            const inDiff = nextFirst.inTicks - prevFirst.inTicks;
            if (inDiff > toleranceTicks) {
                return 0;
            }
        }
        return null;
    }

    function findCutStartByGapMerge(prevSorted, nextSorted, deltaTicks, toleranceTicks) {
        if (!prevSorted || !nextSorted || prevSorted.length < 2 || nextSorted.length < 2) {
            return null;
        }
        const prevStarts = prevSorted.map((clip) => clip.startTicks);
        const nextStarts = nextSorted.map((clip) => clip.startTicks);
        const prevGaps = [];
        const nextGaps = [];
        for (let i = 0; i < prevStarts.length - 1; i += 1) {
            prevGaps.push(prevStarts[i + 1] - prevStarts[i]);
        }
        for (let j = 0; j < nextStarts.length - 1; j += 1) {
            nextGaps.push(nextStarts[j + 1] - nextStarts[j]);
        }
        let i = 0;
        let j = 0;
        while (i < prevGaps.length && j < nextGaps.length) {
            const prevGap = prevGaps[i];
            const nextGap = nextGaps[j];
            if (Math.abs(prevGap - nextGap) <= toleranceTicks) {
                i += 1;
                j += 1;
                continue;
            }
            if (deltaTicks < 0) {
                let sum = 0;
                for (let k = i; k < prevGaps.length; k += 1) {
                    sum += prevGaps[k];
                    if (Math.abs(sum - nextGap) <= toleranceTicks) {
                        return prevStarts[i + 1];
                    }
                    if (sum > nextGap + toleranceTicks) {
                        break;
                    }
                }
            } else if (deltaTicks > 0) {
                let sum = 0;
                for (let k = j; k < nextGaps.length; k += 1) {
                    sum += nextGaps[k];
                    if (Math.abs(sum - prevGap) <= toleranceTicks) {
                        return prevStarts[i + 1];
                    }
                    if (sum > prevGap + toleranceTicks) {
                        break;
                    }
                }
            }
            break;
        }
        return null;
    }

    function findCutStartTicks(prevClips, nextClips, deltaTicks) {
        if (!prevClips || !nextClips || !prevClips.length || !nextClips.length) {
            return null;
        }
        const toleranceTicks = secondsToTicks(SNAPSHOT_TOLERANCE_SECONDS);
        const prevSorted = prevClips.slice().sort((a, b) => a.startTicks - b.startTicks);
        const nextSorted = nextClips.slice().sort((a, b) => a.startTicks - b.startTicks);
        let candidate = null;

        const startCutAtZero = detectStartCutAtZero(prevSorted, nextSorted, deltaTicks, toleranceTicks);
        if (typeof startCutAtZero === 'number' && isFinite(startCutAtZero)) {
            return startCutAtZero;
        }

        for (let i = 0; i < prevSorted.length; i += 1) {
            const prev = prevSorted[i];
            if (!prev || !isFinite(prev.startTicks) || !isFinite(prev.endTicks)) {
                continue;
            }
            const sameStart = findClipByStart(nextSorted, prev.startTicks, toleranceTicks);
            if (sameStart) {
                const prevDur = prev.endTicks - prev.startTicks;
                const nextDur = sameStart.endTicks - sameStart.startTicks;
                if (Math.abs(prevDur - nextDur) > toleranceTicks) {
                    candidate = isFinite(sameStart.endTicks) ? sameStart.endTicks : prev.startTicks;
                    break;
                }
                continue;
            }
            if (deltaTicks > 0) {
                if (findClipByStart(nextSorted, prev.startTicks + deltaTicks, toleranceTicks)) {
                    candidate = prev.startTicks;
                    break;
                }
            }
        }

        if (typeof candidate === 'number' && isFinite(candidate)) {
            return candidate;
        }
        const gapCandidate = findCutStartByGapMerge(prevSorted, nextSorted, deltaTicks, toleranceTicks);
        if (typeof gapCandidate === 'number' && isFinite(gapCandidate)) {
            return gapCandidate;
        }
        return null;
    }

    function findFirstCutFromAnchors(prevTracks, nextTracks, prevEndTicks, nextEndTicks, deltaTicks) {
        if (!prevTracks || !nextTracks || !prevTracks.length || !nextTracks.length) {
            return null;
        }
        const candidates = collectAnchorCandidatesFromTracks(prevTracks, nextTracks, prevEndTicks, nextEndTicks);
        if (!candidates.length) {
            return null;
        }
        const sign = Math.sign(deltaTicks || 0);
        let pool = candidates;
        if (sign !== 0) {
            const signed = candidates.filter((candidate) => Math.sign(candidate.offsetTicks) === sign);
            if (signed.length) {
                pool = signed;
            }
        }
        const v1Pool = pool.filter((candidate) => candidate.label === 'V1' || candidate.label === 'V0');
        const pickFrom = v1Pool.length ? v1Pool : pool;
        let earliest = null;
        pickFrom.forEach((candidate) => {
            if (!candidate || !isFinite(candidate.sourceTicks)) {
                return;
            }
            if (earliest === null || candidate.sourceTicks < earliest) {
                earliest = candidate.sourceTicks;
            }
        });
        return earliest;
    }

    function findCutStartFromTracks(prevTracks, nextTracks, deltaTicks, prevEndTicks, nextEndTicks) {
        if (!prevTracks || !nextTracks || !prevTracks.length || !nextTracks.length) {
            return null;
        }
        const prevMap = {};
        prevTracks.forEach((track, index) => {
            const label = track.label || `T${index}`;
            prevMap[label] = track.clips || [];
        });
        let candidate = null;
        nextTracks.forEach((track, index) => {
            const label = track.label || `T${index}`;
            const prevClips = prevMap[label];
            if (!prevClips || !prevClips.length) {
                return;
            }
            const cutStart = findCutStartTicks(prevClips, track.clips || [], deltaTicks);
            if (typeof cutStart === 'number' && isFinite(cutStart)) {
                if (candidate === null || cutStart < candidate) {
                    candidate = cutStart;
                }
            }
        });
        if (typeof candidate === 'number' && isFinite(candidate)) {
            return candidate;
        }
        return findFirstCutFromAnchors(prevTracks, nextTracks, prevEndTicks, nextEndTicks, deltaTicks);
    }

    function buildAnchorsFromTrack(baselineClips, currentClips, baselineEndTicks, currentEndTicks) {
        if (!baselineClips || !currentClips) {
            return [];
        }
        const anchors = [];
        const toleranceTicks = SNAPSHOT_TOLERANCE_SECONDS * TICKS_PER_SECOND;
        let cumulativeOffsetTicks = 0;
        const max = Math.min(baselineClips.length, currentClips.length);
        for (let i = 0; i < max; i += 1) {
            const base = baselineClips[i];
            const curr = currentClips[i];
            if (!base || !curr) {
                break;
            }
            const expectedStart = base.startTicks + cumulativeOffsetTicks;
            const startDiff = curr.startTicks - expectedStart;
            if (Math.abs(startDiff) > toleranceTicks) {
                cumulativeOffsetTicks += startDiff;
                anchors.push({ sourceTicks: base.startTicks, offsetTicks: cumulativeOffsetTicks });
            }
            const baseDur = base.endTicks - base.startTicks;
            const currDur = curr.endTicks - curr.startTicks;
            const durDiff = currDur - baseDur;
            if (Math.abs(durDiff) > toleranceTicks) {
                cumulativeOffsetTicks += durDiff;
                anchors.push({ sourceTicks: base.endTicks, offsetTicks: cumulativeOffsetTicks });
            }
        }
        if (isFinite(baselineEndTicks) && isFinite(currentEndTicks)) {
            const totalDelta = currentEndTicks - baselineEndTicks;
            const gap = totalDelta - cumulativeOffsetTicks;
            if (Math.abs(gap) > toleranceTicks) {
                cumulativeOffsetTicks += gap;
                anchors.push({ sourceTicks: baselineEndTicks, offsetTicks: cumulativeOffsetTicks });
            }
        }
        anchors.sort((a, b) => a.sourceTicks - b.sourceTicks);
        const normalized = [];
        let lastOffset = 0;
        anchors.forEach((anchor) => {
            if (!normalized.length) {
                normalized.push(anchor);
                lastOffset = anchor.offsetTicks;
                return;
            }
            if (Math.abs(anchor.offsetTicks - lastOffset) > toleranceTicks) {
                normalized.push(anchor);
                lastOffset = anchor.offsetTicks;
            }
        });
        return normalized;
    }

    function collectAnchorCandidatesFromTracks(baselineTracks, currentTracks, baselineEndTicks, currentEndTicks) {
        if (!baselineTracks || !currentTracks) {
            return [];
        }
        const isV1 = (label) => label === 'V1' || label === 'V0';
        const currentMap = {};
        currentTracks.forEach((track, index) => {
            const label = track.label || `T${index}`;
            currentMap[label] = track.clips || [];
        });
        const candidates = [];
        baselineTracks.forEach((track, index) => {
            const label = track.label || `T${index}`;
            const baselineClips = track.clips || [];
            const currentClips = currentMap[label];
            if (!baselineClips.length || !currentClips || !currentClips.length) {
                return;
            }
            const anchors = buildAnchorsFromTrack(baselineClips, currentClips, baselineEndTicks, currentEndTicks);
            anchors.forEach((anchor) => {
                candidates.push({
                    sourceTicks: anchor.sourceTicks,
                    offsetTicks: anchor.offsetTicks,
                    label
                });
            });
        });
        const v1Candidates = candidates.filter((candidate) => isV1(candidate.label));
        return v1Candidates.length ? v1Candidates : candidates;
    }

    function mergeAnchorCandidates(candidates) {
        if (!candidates.length) {
            return [];
        }
        const toleranceTicks = SNAPSHOT_TOLERANCE_SECONDS * TICKS_PER_SECOND;
        const sorted = candidates.slice().sort((a, b) => a.sourceTicks - b.sourceTicks);
        const merged = [];
        sorted.forEach((candidate) => {
            const exists = merged.some((existing) => Math.abs(existing.offsetTicks - candidate.offsetTicks) <= toleranceTicks);
            if (exists) {
                return;
            }
            merged.push({
                sourceTicks: candidate.sourceTicks,
                offsetTicks: candidate.offsetTicks
            });
        });
        merged.sort((a, b) => a.sourceTicks - b.sourceTicks);
        return merged;
    }

    function rebuildAnchorsFromBaseline(currentTracks, currentEndTicks) {
        if (!baselineTrackSnapshot || !baselineTrackSnapshot.length) {
            return false;
        }
        if (!currentTracks || !currentTracks.length) {
            setAutoFollowStatus('自動補正: トラック情報なし');
            return false;
        }
        const candidates = collectAnchorCandidatesFromTracks(
            baselineTrackSnapshot,
            currentTracks,
            baselineSequenceEndTicks,
            currentEndTicks
        );
        const anchorTicks = mergeAnchorCandidates(candidates);
        if (!anchorTicks.length) {
            const toleranceTicks = SNAPSHOT_TOLERANCE_SECONDS * TICKS_PER_SECOND;
            if (isFinite(baselineSequenceEndTicks) && isFinite(currentEndTicks)
                && Math.abs(currentEndTicks - baselineSequenceEndTicks) <= toleranceTicks) {
                anchors = [];
                lastAnchorMeta = null;
                persistAnchors();
                renderAnchors();
                refreshList();
                setAutoFollowStatus('自動補正: 差分 +0');
                return true;
            }
            setAutoFollowStatus('自動補正: カット位置不明');
            return false;
        }
        anchors = anchorTicks.map((anchor) => {
            return {
                sourceTicks: anchor.sourceTicks,
                targetTicks: anchor.sourceTicks + anchor.offsetTicks,
                offsetTicks: anchor.offsetTicks
            };
        });
        anchors.sort((a, b) => a.sourceTicks - b.sourceTicks);
        lastAnchorMeta = anchors.length ? anchors[anchors.length - 1] : null;
        persistAnchors();
        renderAnchors();
        refreshList();
        const baseOffsetTicks = (typeof firstEntryTicks === 'number' && isFinite(firstEntryTicks))
            ? getOffsetForSourceTicks(firstEntryTicks)
            : (lastAnchorMeta ? lastAnchorMeta.offsetTicks : 0);
        setAutoFollowStatus('自動補正: 差分 ' + formatOffsetTicks(baseOffsetTicks));
        return true;
    }

    function updateTimelineContext(done) {
        cs.evalScript('fbjumper_getPlayheadTicks()', function(result) {
            const parsed = parsePlayheadResult(result);
            if (parsed.ok) {
                lastObservedPlayheadTicks = parsed.ticks;
                lastObservedPlayheadAt = Date.now();
            }
            cs.evalScript('fbjumper_getSelectionRangeTicks()', function(selectionResult) {
                const selection = parseSelectionRangeResult(selectionResult);
                if (selection.ok) {
                    lastObservedSelection = selection;
                    lastObservedSelectionAt = Date.now();
                }
                if (typeof done === 'function') {
                    done();
                }
            });
        });
    }

    function buildAnchorTarget(deltaTicks, context) {
        if (!context) {
            return { ok: false, error: '再生位置取得失敗' };
        }
        const playheadTicks = (typeof context.playheadTicks === 'number' && isFinite(context.playheadTicks))
            ? context.playheadTicks
            : null;
        if (context.selection) {
            const selStart = context.selection.startTicks;
            const selEnd = context.selection.endTicks;
            if (playheadTicks !== null) {
                const toleranceTicks = secondsToTicks(AUTO_ANCHOR_TOLERANCE_SECONDS);
                const inSelection = playheadTicks >= selStart - toleranceTicks
                    && playheadTicks <= selEnd + toleranceTicks;
                if (inSelection) {
                    return { ok: true, anchorTargetTicks: playheadTicks, anchorLabel: '再生ヘッド' };
                }
            }
            const anchorTargetTicks = deltaTicks >= 0 ? selEnd : selStart;
            const anchorLabel = deltaTicks >= 0 ? '選択終了' : '選択開始';
            if (!isFinite(anchorTargetTicks)) {
                return { ok: false, error: '選択範囲の取得に失敗しました' };
            }
            return { ok: true, anchorTargetTicks, anchorLabel };
        }
        if (playheadTicks !== null) {
            return { ok: true, anchorTargetTicks: playheadTicks, anchorLabel: '再生ヘッド' };
        }
        return { ok: false, error: '再生位置取得失敗' };
    }

    function resolveAnchorContext(context, done) {
        const hasPlayhead = context && typeof context.playheadTicks === 'number' && isFinite(context.playheadTicks);
        const hasSelection = context && context.selection;
        if (hasPlayhead || hasSelection) {
            done({
                playheadTicks: hasPlayhead ? context.playheadTicks : null,
                selection: hasSelection ? context.selection : null
            });
            return;
        }
        ensureBoundSequence(function(ready) {
            if (!ready) {
                setAutoFollowStatus('自動追従: シーケンス未アクティブ');
                done({ playheadTicks: null, selection: null });
                return;
            }
            cs.evalScript('fbjumper_getSelectionRangeTicks()', function(selectionResult) {
                const selection = parseSelectionRangeResult(selectionResult);
                cs.evalScript('fbjumper_getPlayheadTicks()', function(result) {
                    const parsed = parsePlayheadResult(result);
                    if (!parsed.ok) {
                        setAutoFollowStatus('自動追従: 再生位置取得失敗');
                        return;
                    }
                    done({
                        playheadTicks: parsed.ticks,
                        selection: selection.ok ? selection : null
                    });
                });
            });
        }, { silent: true });
    }

    function applyAutoAnchor(deltaTicks, anchorTargetTicks, anchorLabel, sequenceContext) {
        const sourceTicks = findSourceTicksForTarget(anchorTargetTicks);
        if (sourceTicks === null || !isFinite(sourceTicks)) {
            setAutoFollowStatus('自動補正: 対象なし');
            return;
        }
        const offsetBefore = getOffsetForSourceTicks(sourceTicks);
        const targetBefore = sourceTicks + offsetBefore;
        const targetAfter = targetBefore + deltaTicks;
        if (!isFinite(targetAfter) || !isFinite(targetBefore)) {
            setAutoFollowStatus('自動追従: 補正に失敗しました');
            return;
        }
        const existingIndex = findAnchorIndexAtSource(sourceTicks);
        const prevAnchor = existingIndex >= 0 ? { ...anchors[existingIndex] } : null;
        shiftAnchorsAfterSource(sourceTicks, deltaTicks);
        upsertAutoAnchor(sourceTicks, targetAfter);
        lastAutoAdjustment = {
            sourceTicks,
            targetTicks: targetAfter,
            deltaTicks,
            anchorTargetTicks,
            hadAnchorBefore: !!prevAnchor,
            previousTargetTicks: prevAnchor ? prevAnchor.targetTicks : null,
            sequenceEndBefore: sequenceContext ? sequenceContext.sequenceEndBefore : null,
            sequenceEndAfter: sequenceContext ? sequenceContext.sequenceEndAfter : null
        };
        setAutoFollowStatus('自動補正: ' + formatOffsetTicks(deltaTicks) + ' @ ' + truncatedTimecodeFromTicks(sourceTicks) + ' (' + anchorLabel + ')');
    }

    function removeAnchorAtSource(sourceTicks) {
        const index = findAnchorIndexAtSource(sourceTicks);
        if (index >= 0) {
            anchors.splice(index, 1);
            return true;
        }
        return false;
    }

    function syncAnchorMetaFromAnchors() {
        if (!anchors.length) {
            lastAnchorMeta = null;
        } else {
            const latest = anchors[anchors.length - 1];
            lastAnchorMeta = {
                sourceTicks: latest.sourceTicks,
                targetTicks: latest.targetTicks,
                offsetTicks: latest.offsetTicks
            };
        }
        renderAnchors();
        refreshList();
    }

    function applyUndoAdjustment(deltaTicks, context) {
        if (!lastAutoAdjustment || !isFinite(lastAutoAdjustment.deltaTicks)) {
            return false;
        }
        const prevTicks = lastAutoAdjustment.deltaTicks;
        if (prevTicks === 0 || Math.sign(prevTicks) === Math.sign(deltaTicks)) {
            return false;
        }
        const toleranceTicks = secondsToTicks(AUTO_UNDO_TOLERANCE_SECONDS);
        const tickGap = Math.abs(Math.abs(prevTicks) - Math.abs(deltaTicks));
        const undoByDelta = tickGap <= toleranceTicks;
        let undoByLength = false;
        if (context && isFinite(context.sequenceEndAfter) && isFinite(lastAutoAdjustment.sequenceEndBefore)) {
            undoByLength = Math.abs(context.sequenceEndAfter - lastAutoAdjustment.sequenceEndBefore) <= toleranceTicks;
        }
        if (!undoByDelta && !undoByLength) {
            return false;
        }
        const sourceTicks = lastAutoAdjustment.sourceTicks;
        if (!isFinite(sourceTicks)) {
            return false;
        }
        shiftAnchorsAfterSource(sourceTicks, deltaTicks);
        if (lastAutoAdjustment.hadAnchorBefore && isFinite(lastAutoAdjustment.previousTargetTicks)) {
            upsertAutoAnchor(sourceTicks, lastAutoAdjustment.previousTargetTicks);
        } else {
            removeAnchorAtSource(sourceTicks);
            persistAnchors();
            syncAnchorMetaFromAnchors();
        }
        lastAutoAdjustment = null;
        setAutoFollowStatus('自動補正: Undo ' + formatOffsetTicks(deltaTicks));
        return true;
    }

    function upsertAutoAnchor(sourceTicks, targetTicks) {
        const offsetTicks = targetTicks - sourceTicks;
        const toleranceTicks = secondsToTicks(AUTO_ANCHOR_TOLERANCE_SECONDS);
        let replaced = false;
        for (let i = 0; i < anchors.length; i += 1) {
            if (Math.abs(anchors[i].sourceTicks - sourceTicks) <= toleranceTicks) {
                anchors[i] = { sourceTicks, targetTicks, offsetTicks };
                replaced = true;
                break;
            }
        }
        if (!replaced) {
            anchors.push({ sourceTicks, targetTicks, offsetTicks });
        }
        lastAnchorMeta = { sourceTicks, targetTicks, offsetTicks };
        anchors.sort((a, b) => a.sourceTicks - b.sourceTicks);
        persistAnchors();
        renderAnchors();
        refreshList();
        return replaced;
    }

    function shiftAnchorsAfterSource(sourceTicks, deltaTicks) {
        if (!anchors.length) {
            return false;
        }
        const toleranceTicks = secondsToTicks(AUTO_ANCHOR_TOLERANCE_SECONDS);
        let updated = false;
        for (let i = 0; i < anchors.length; i += 1) {
            const anchor = anchors[i];
            if (anchor.sourceTicks > sourceTicks + toleranceTicks) {
                anchor.targetTicks += deltaTicks;
                anchor.offsetTicks = anchor.targetTicks - anchor.sourceTicks;
                updated = true;
            }
        }
        return updated;
    }

    function resolveCutTargetTicks(deltaTicks, cutTargetTicks, context) {
        let targetTicks = cutTargetTicks;
        let label = 'カット位置';
        const toleranceTicks = secondsToTicks(AUTO_ANCHOR_TOLERANCE_SECONDS);
        if (isFinite(cutTargetTicks) && Math.abs(cutTargetTicks) <= toleranceTicks) {
            targetTicks = 0;
            label = '先頭カット';
        }
        if (deltaTicks < 0 && context) {
            const selection = context.selection;
            const selectionAt = context.selectionAt;
            const selectionFresh = selection && selectionAt
                && (Date.now() - selectionAt) <= AUTO_FOLLOW_SELECTION_STALE_MS;
            if (selectionFresh && selection) {
                const selStartOk = selection.startTicks <= toleranceTicks;
                const selLen = Math.abs(selection.endTicks - selection.startTicks);
                const deltaAbs = Math.abs(deltaTicks);
                if (selStartOk && Math.abs(selLen - deltaAbs) <= toleranceTicks * 2) {
                    targetTicks = 0;
                    label = '先頭カット';
                }
            }
        }
        return { targetTicks, label };
    }

    function handleSequenceDurationDelta(deltaTicks, context) {
        if (applyUndoAdjustment(deltaTicks, context)) {
            return;
        }
        if (context && typeof context.cutTargetTicks === 'number' && isFinite(context.cutTargetTicks)) {
            const resolved = resolveCutTargetTicks(deltaTicks, context.cutTargetTicks, context);
            applyAutoAnchor(deltaTicks, resolved.targetTicks, resolved.label, context);
            return;
        }
        if (context && context.snapshotAvailable && context.cutDetectionFailed) {
            const selection = context.selection;
            const selectionAt = context.selectionAt;
            const selectionFresh = selection && selectionAt
                && (Date.now() - selectionAt) <= AUTO_FOLLOW_SELECTION_STALE_MS;
            if (selectionFresh) {
                const anchorTargetTicks = deltaTicks >= 0 ? selection.endTicks : selection.startTicks;
                const anchorLabel = deltaTicks >= 0 ? '選択終了' : '選択開始';
                if (isFinite(anchorTargetTicks)) {
                    applyAutoAnchor(deltaTicks, anchorTargetTicks, anchorLabel, context);
                    return;
                }
            }
            setAutoFollowStatus('自動補正: カット位置不明');
            return;
        }
        resolveAnchorContext(context, function(resolved) {
            const anchor = buildAnchorTarget(deltaTicks, resolved);
            if (!anchor.ok) {
                setAutoFollowStatus('自動追従: ' + (anchor.error || '補正に失敗しました'));
                return;
            }
            applyAutoAnchor(deltaTicks, anchor.anchorTargetTicks, anchor.anchorLabel, context);
        });
    }

    function finalizePendingBatch(context) {
        if (!pendingBaselineSnapshot || !pendingLatestSnapshot) {
            resetPendingBatch();
            return false;
        }
        if (!isFinite(pendingBaselineEndTicks) || !isFinite(pendingLatestEndTicks)) {
            resetPendingBatch();
            return false;
        }
        const totalDeltaTicks = pendingLatestEndTicks - pendingBaselineEndTicks;
        if (Math.abs(totalDeltaTicks) < secondsToTicks(AUTO_FOLLOW_MIN_DELTA_SECONDS)) {
            resetPendingBatch();
            return false;
        }
        const cutTargetTicks = findCutStartFromTracks(
            pendingBaselineSnapshot,
            pendingLatestSnapshot,
            totalDeltaTicks,
            pendingBaselineEndTicks,
            pendingLatestEndTicks
        );
        handleSequenceDurationDelta(totalDeltaTicks, {
            cutTargetTicks,
            snapshotAvailable: true,
            cutDetectionFailed: !cutTargetTicks,
            sequenceEndBefore: pendingBaselineEndTicks,
            sequenceEndAfter: pendingLatestEndTicks,
            playheadTicks: context && isFinite(context.playheadTicks) ? context.playheadTicks : null,
            playheadAt: context ? context.playheadAt : null,
            selection: context ? context.selection : null,
            selectionAt: context ? context.selectionAt : null
        });
        resetPendingBatch();
        return true;
    }

    function pollSequenceDuration() {
        if (!autoFollowEnabled || autoFollowInFlight) {
            return;
        }
        autoFollowInFlight = true;
        ensureBoundSequence(function(ready) {
            if (!ready) {
                setAutoFollowStatus('自動追従: シーケンス未アクティブ');
                autoFollowInFlight = false;
                return;
            }
            updateTimelineContext(function() {
                cs.evalScript('fbjumper_getSequenceEndTicks()', function(result) {
                    const parsed = parseSequenceEndResult(result);
                    if (!parsed.ok) {
                        setAutoFollowStatus('自動追従: ' + (parsed.error || '失敗'));
                        autoFollowInFlight = false;
                        return;
                    }
                    fetchTrackSnapshot(function(snapshotResult) {
                        autoFollowInFlight = false;
                        if (!snapshotResult.ok) {
                            setAutoFollowStatus('自動補正: トラック情報取得失敗');
                            return;
                        }
                        const currentSnapshot = snapshotResult.tracks;
                        if (!lastTrackSnapshot) {
                            lastTrackSnapshot = currentSnapshot;
                            lastSequenceEndTicks = parsed.ticks;
                            resetPendingBatch();
                            anchors = [];
                            lastAnchorMeta = null;
                            persistAnchors();
                            renderAnchors();
                            refreshList();
                            setAutoFollowStatus('自動追従: 基準記録');
                            return;
                        }
                        const previousEndTicks = lastSequenceEndTicks;
                        const deltaTicks = parsed.ticks - previousEndTicks;
                        lastSequenceEndTicks = parsed.ticks;
                        if (Math.abs(deltaTicks) < secondsToTicks(AUTO_FOLLOW_MIN_DELTA_SECONDS)) {
                            lastTrackSnapshot = currentSnapshot;
                            if (hasPendingBatch() && isPendingBatchSettled()) {
                                finalizePendingBatch({
                                    playheadTicks: lastObservedPlayheadTicks,
                                    playheadAt: lastObservedPlayheadAt,
                                    selection: lastObservedSelection,
                                    selectionAt: lastObservedSelectionAt
                                });
                            }
                            return;
                        }

                        if (!hasPendingBatch()) {
                            startPendingBatch(lastTrackSnapshot, previousEndTicks);
                        }
                        updatePendingBatch(currentSnapshot, parsed.ticks);
                        lastTrackSnapshot = currentSnapshot;
                        setAutoFollowStatus('自動補正: バッチ処理中…');
                    });
                });
            });
        }, { silent: true });
    }

    function startAutoFollow() {
        if (autoFollowTimer) {
            return;
        }
        refreshTimebase();
        lastSequenceEndTicks = null;
        lastTrackSnapshot = null;
        baselineTrackSnapshot = null;
        baselineSequenceEndTicks = null;
        lastObservedPlayheadTicks = null;
        lastObservedPlayheadAt = null;
        lastObservedSelection = null;
        lastObservedSelectionAt = null;
        resetPendingBatch();
        setAutoFollowStatus('自動追従: 監視準備中');
        autoFollowTimer = setInterval(pollSequenceDuration, AUTO_FOLLOW_POLL_MS);
        pollSequenceDuration();
    }

    function stopAutoFollow() {
        if (autoFollowTimer) {
            clearInterval(autoFollowTimer);
            autoFollowTimer = null;
        }
        lastSequenceEndTicks = null;
        lastTrackSnapshot = null;
        baselineTrackSnapshot = null;
        baselineSequenceEndTicks = null;
        lastObservedPlayheadTicks = null;
        lastObservedPlayheadAt = null;
        lastObservedSelection = null;
        lastObservedSelectionAt = null;
        resetPendingBatch();
        setAutoFollowStatus('停止中');
    }

    function saveAutoFollow(enabled) {
        try {
            localStorage.setItem(STORAGE_AUTO_FOLLOW, enabled ? 'true' : 'false');
        } catch (e) {
            console.log('[FB Jumper] auto follow save failed', e);
        }
    }

    function setAutoFollowEnabled(enabled) {
        const next = !!enabled;
        if (autoFollowEnabled === next) {
            return;
        }
        autoFollowEnabled = next;
        if (autoFollowToggle) {
            autoFollowToggle.checked = next;
        }
        saveAutoFollow(next);
        if (next) {
            startAutoFollow();
        } else {
            stopAutoFollow();
        }
    }

    function loadAutoFollow() {
        let enabled = true;
        try {
            const raw = localStorage.getItem(STORAGE_AUTO_FOLLOW);
            if (raw !== null) {
                enabled = raw === 'true';
            }
        } catch (e) {
            enabled = true;
        }
        setAutoFollowEnabled(enabled);
    }

    if (autoFollowToggle) {
        autoFollowToggle.addEventListener('change', () => {
            setAutoFollowEnabled(autoFollowToggle.checked);
        });
    }

    // Boot: ensure QE is enabled before first action
    cs.evalScript('fbjumper_enableQE()', function(result) {
        console.log('[FB Jumper] QE Enable result:', result);
        handleResult(result);
    });

    // Boot: load anchors and render
    loadAnchors();
    renderAnchors();
    loadAutoFollow();
})();
